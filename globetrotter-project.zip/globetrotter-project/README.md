# GlobeTrotter — project structure

Your uploaded file (`globetrotter__6_.html`) is a self-contained front-end
demo: all state lives in the browser, "login" is fake, and the trip
data (cities, activities, costs) is hardcoded in JS. It doesn't have a
backend, database, or AI/API layer yet — so those three folders below
are scaffolded to match what the frontend already expects (its auth
flow, its city list, its "chat with your trip assistant" mention),
ready for you to fill in and connect.

```
globetrotter-project/
├── frontend/                  # your uploaded app, unchanged
│   └── index.html
├── backend/                   # Node/Express API
│   ├── src/server.js
│   ├── src/routes/            # auth, trips/stops, cities
│   ├── src/middleware/        # JWT auth, rate limiting, error handling
│   └── src/services/db.js     # Postgres connection
├── database/                  # PostgreSQL schema + seed data
│   ├── migrations/001_init.sql
│   └── seeds/001_cities.sql   # matches the 9 cities in the frontend
└── ai_api_cybersecurity/
    ├── ai/                    # trip assistant (Anthropic API)
    ├── api-management/        # key handling, usage/rate tracking
    └── cybersecurity/         # sanitization, password policy, security notes
```

## To run
1. `database/` — create the Postgres DB and run the migration + seed
2. `backend/` — `cp .env.example .env`, fill in values, `npm install`, `npm run dev`
3. `frontend/index.html` — open directly, or point its fetch calls at the backend once you wire them up (currently everything is local state)
